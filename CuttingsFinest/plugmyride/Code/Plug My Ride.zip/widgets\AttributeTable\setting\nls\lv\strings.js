﻿define({
    label: "ķ_Layer_ū",
    show: "ķ_Show_ū",
    actions: "ķ_Selection Symbol_ū",
    field: "ķ_Field_ū",
    alias: "ķ_Alias_ū",
    visible: "ķ_Visible_ū",
    linkField: "ķ_LinkField_ū",
    noLayers: "ķ_No feature layers available_ū",
    back: "ķ_Back_ū",
    exportCSV: "ķ_Export to CSV_ū",
    restore: "ķ_Restore to default value_ū",
    ok: "ķ_OK_ū",
    result: "ķ_Save successfully_ū",
    warning: "ķ_Check to show this layer in table firstly._ū"
});
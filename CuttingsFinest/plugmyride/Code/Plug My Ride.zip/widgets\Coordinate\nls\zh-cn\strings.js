﻿define({
    hintMessage: "点击地图以获取坐标",
    defaultLabel: "默认设置",
    realtimeLabel: "移动鼠标以获取坐标",
    computing: "计算中...",
    latitudeLabel: "纬度",
    longitudeLabel: "经度"
  });
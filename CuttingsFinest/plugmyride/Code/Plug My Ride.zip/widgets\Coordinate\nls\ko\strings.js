﻿define({

    hintMessage: "한_Click map to get coordinate_빠",
    defaultLabel: "한_Default Settings_빠",
    realtimeLabel: "한_Can Realtime Show_빠",
    computing: "한_computing..._빠",
    latitudeLabel: "한_Latitude_빠",
    longitudeLabel: "한_Longitude_빠"
});
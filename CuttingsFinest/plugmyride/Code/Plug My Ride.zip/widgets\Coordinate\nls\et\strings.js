﻿define({

    hintMessage: "Š_Click map to get coordinate_ä",
    defaultLabel: "Š_Default Settings_ä",
    realtimeLabel: "Š_Can Realtime Show_ä",
    computing: "Š_computing..._ä",
    latitudeLabel: "Š_Latitude_ä",
    longitudeLabel: "Š_Longitude_ä"
});
﻿define({
    signin: "ı_Sign In_İ",
    signout: "ı_Sign Out_İ",
    about: "ı_About_İ",
    signInTo: "ı_Sign in to_İ"
});

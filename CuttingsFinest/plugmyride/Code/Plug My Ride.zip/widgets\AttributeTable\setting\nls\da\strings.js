﻿define({
    label: "ø_Layer_å",
    show: "ø_Show_å",
    actions: "ø_Selection Symbol_å",
    field: "ø_Field_å",
    alias: "ø_Alias_å",
    visible: "ø_Visible_å",
    linkField: "ø_LinkField_å",
    noLayers: "ø_No feature layers available_å",
    back: "ø_Back_å",
    exportCSV: "ø_Export to CSV_å",
    restore: "ø_Restore to default value_å",
    ok: "ø_OK_å",
    result: "ø_Save successfully_å",
    warning: "ø_Check to show this layer in table firstly._å"
});
﻿define({
    group: "بيت_Name_لاحقة",
    openAll: "بيت_Open All in Panel_لاحقة",
    dropDown: "بيت_Show in Drop-down Menu_لاحقة",
    noGroup: "بيت_There is no widget group set._لاحقة",
    groupSetLabel: "بيت_Set widget groups properties_لاحقة"
});
﻿define({

    hintMessage: "ก้_Click map to get coordinate_ษฺ",
    defaultLabel: "ก้_Default Settings_ษฺ",
    realtimeLabel: "ก้_Can Realtime Show_ษฺ",
    computing: "ก้_computing..._ษฺ",
    latitudeLabel: "ก้_Latitude_ษฺ",
    longitudeLabel: "ก้_Longitude_ษฺ"
});
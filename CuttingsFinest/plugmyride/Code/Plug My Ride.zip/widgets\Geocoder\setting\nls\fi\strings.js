﻿define({

    placeholder: "Å_Placeholder Text_ö",
    url: "Å_Geocoder URL_ö",
    name: "Å_Geocoder Name_ö",
    singleLineFieldName: "Å_SingleLineFieldName_ö",
    portalConnectionError: 'Å_Can not get the configuratin of geocode from protal_ö',
    actions: "Å_Actions_ö",
    warning: "Å_Incorrect Service_ö",
    instruction: "Å_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ö
    Å_"You can also reorder,configure,or delete your geocoders bleow._ö",
    add: "Å_Add Geocoder_ö",
    edit: "Å_Edit Geocoder_ö",
    ok: "Å_OK_ö",
    cancel: "Å_Cancel_ö",
    REPEATING_ERROR: "Å_The fllowing fields are repeated:_ö "
});
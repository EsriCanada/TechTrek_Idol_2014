﻿define({
    showLegend: "Ĳ_Show Legend_ä"
});
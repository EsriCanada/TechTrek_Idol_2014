﻿define({
    titleBasemap: 'Ă_Base maps_ș',
    titleLayers: 'Ă_Operational Layers_ș',
    labelLayer: 'Ă_Layer Name_ș',
    itemZoomTo: 'Ă_Zoom to_ș',
    itemTransparency: 'Ă_Transparency_ș',
    itemTransparent: 'Ă_Transparent_ș',
    itemOpaque: 'Ă_Opaque_ș',
    itemMoveUp: 'Ă_Move up_ș',
    itemMoveDown: 'Ă_Move down_ș',
    itemDesc: 'Ă_Description_ș',
    itemDownload: 'Ă_Download_ș',
    itemToAttributeTable: 'Ă_Open attribute table_ș'
});

﻿define({

    placeholder: "ł_Placeholder Text_ą",
    url: "ł_Geocoder URL_ą",
    name: "ł_Geocoder Name_ą",
    singleLineFieldName: "ł_SingleLineFieldName_ą",
    portalConnectionError: 'ł_Can not get the configuratin of geocode from protal_ą',
    actions: "ł_Actions_ą",
    warning: "ł_Incorrect Service_ą",
    instruction: "ł_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ą
    ł_"You can also reorder,configure,or delete your geocoders bleow._ą",
    add: "ł_Add Geocoder_ą",
    edit: "ł_Edit Geocoder_ą",
    ok: "ł_OK_ą",
    cancel: "ł_Cancel_ą",
    REPEATING_ERROR: "ł_The fllowing fields are repeated:_ą "
});
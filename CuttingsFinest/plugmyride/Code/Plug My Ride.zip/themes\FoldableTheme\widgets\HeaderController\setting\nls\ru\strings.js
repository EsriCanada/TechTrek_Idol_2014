﻿define({
    group: "Ж_Name_Я",
    openAll: "Ж_Open All in Panel_Я",
    dropDown: "Ж_Show in Drop-down Menu_Я",
    noGroup: "Ж_There is no widget group set._Я",
    groupSetLabel: "Ж_Set widget groups properties_Я"
});
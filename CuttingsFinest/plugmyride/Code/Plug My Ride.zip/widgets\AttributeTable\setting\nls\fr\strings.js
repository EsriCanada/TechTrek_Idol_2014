﻿define({
    label: "æ_Layer_Â",
    show: "æ_Show_Â",
    actions: "æ_Selection Symbol_Â",
    field: "æ_Field_Â",
    alias: "æ_Alias_Â",
    visible: "æ_Visible_Â",
    linkField: "æ_LinkField_Â",
    noLayers: "æ_No feature layers available_Â",
    back: "æ_Back_Â",
    exportCSV: "æ_Export to CSV_Â",
    restore: "æ_Restore to default value_Â",
    ok: "æ_OK_Â",
    result: "æ_Save successfully_Â",
    warning: "æ_Check to show this layer in table firstly._Â"
});
﻿define({
    label: "Å_Layer_ö",
    show: "Å_Show_ö",
    actions: "Å_Selection Symbol_ö",
    field: "Å_Field_ö",
    alias: "Å_Alias_ö",
    visible: "Å_Visible_ö",
    linkField: "Å_LinkField_ö",
    noLayers: "Å_No feature layers available_ö",
    back: "Å_Back_ö",
    exportCSV: "Å_Export to CSV_ö",
    restore: "Å_Restore to default value_ö",
    ok: "Å_OK_ö",
    result: "Å_Save successfully_ö",
    warning: "Å_Check to show this layer in table firstly._ö"
});
﻿define({
    signin: "ก้_Sign In_ษฺ",
    signout: "ก้_Sign Out_ษฺ",
    about: "ก้_About_ษฺ",
    signInTo: "ก้_Sign in to_ษฺ"
});

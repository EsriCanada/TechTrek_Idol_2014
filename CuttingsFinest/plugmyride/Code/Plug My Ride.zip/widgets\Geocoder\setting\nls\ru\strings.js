﻿define({

    placeholder: "Ж_Placeholder Text_Я",
    url: "Ж_Geocoder URL_Я",
    name: "Ж_Geocoder Name_Я",
    singleLineFieldName: "Ж_SingleLineFieldName_Я",
    portalConnectionError: 'Ж_Can not get the configuratin of geocode from protal_Я',
    actions: "Ж_Actions_Я",
    warning: "Ж_Incorrect Service_Я",
    instruction: "Ж_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_Я
    Ж_"You can also reorder,configure,or delete your geocoders bleow._Я",
    add: "Ж_Add Geocoder_Я",
    edit: "Ж_Edit Geocoder_Я",
    ok: "Ж_OK_Я",
    cancel: "Ж_Cancel_Я",
    REPEATING_ERROR: "Ж_The fllowing fields are repeated:_Я "
});
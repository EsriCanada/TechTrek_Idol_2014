﻿define({
    showLegend: "Ř_Show Legend_ů"
});
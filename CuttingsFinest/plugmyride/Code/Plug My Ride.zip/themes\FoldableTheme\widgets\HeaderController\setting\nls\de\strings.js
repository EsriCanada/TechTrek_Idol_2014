﻿define({
    group: "ä_Name_Ü",
    openAll: "ä_Open All in Panel_Ü",
    dropDown: "ä_Show in Drop-down Menu_Ü",
    noGroup: "ä_There is no widget group set._Ü",
    groupSetLabel: "ä_Set widget groups properties_Ü"
});
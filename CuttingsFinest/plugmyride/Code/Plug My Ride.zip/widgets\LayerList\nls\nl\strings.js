﻿define({
    titleBasemap: 'Ĳ_Base maps_ä',
    titleLayers: 'Ĳ_Operational Layers_ä',
    labelLayer: 'Ĳ_Layer Name_ä',
    itemZoomTo: 'Ĳ_Zoom to_ä',
    itemTransparency: 'Ĳ_Transparency_ä',
    itemTransparent: 'Ĳ_Transparent_ä',
    itemOpaque: 'Ĳ_Opaque_ä',
    itemMoveUp: 'Ĳ_Move up_ä',
    itemMoveDown: 'Ĳ_Move down_ä',
    itemDesc: 'Ĳ_Description_ä',
    itemDownload: 'Ĳ_Download_ä',
    itemToAttributeTable: 'Ĳ_Open attribute table_ä'
});

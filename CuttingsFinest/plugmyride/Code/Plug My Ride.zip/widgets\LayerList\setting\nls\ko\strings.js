﻿define({
    showLegend: "한_Show Legend_빠"
});
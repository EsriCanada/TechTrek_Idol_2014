﻿define({
    titleBasemap: 'é_Base maps_È',
    titleLayers: 'é_Operational Layers_È',
    labelLayer: 'é_Layer Name_È',
    itemZoomTo: 'é_Zoom to_È',
    itemTransparency: 'é_Transparency_È',
    itemTransparent: 'é_Transparent_È',
    itemOpaque: 'é_Opaque_È',
    itemMoveUp: 'é_Move up_È',
    itemMoveDown: 'é_Move down_È',
    itemDesc: 'é_Description_È',
    itemDownload: 'é_Download_È',
    itemToAttributeTable: 'é_Open attribute table_È'
});

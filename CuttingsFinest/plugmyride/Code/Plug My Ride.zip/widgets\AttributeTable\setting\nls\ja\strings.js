﻿define({
    label: "須_Layer_鷗",
    show: "須_Show_鷗",
    actions: "須_Selection Symbol_鷗",
    field: "須_Field_鷗",
    alias: "須_Alias_鷗",
    visible: "須_Visible_鷗",
    linkField: "須_LinkField_鷗",
    noLayers: "須_No feature layers available_鷗",
    back: "須_Back_鷗",
    exportCSV: "須_Export to CSV_鷗",
    restore: "須_Restore to default value_鷗",
    ok: "須_OK_鷗",
    result: "須_Save successfully_鷗",
    warning: "須_Check to show this layer in table firstly._鷗"
});
﻿define({
    signin: "Å_Sign In_ö",
    signout: "Å_Sign Out_ö",
    about: "Å_About_ö",
    signInTo: "Å_Sign in to_ö"
});

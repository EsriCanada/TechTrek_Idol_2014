﻿define({

    hintMessage: "Ř_Click map to get coordinate_ů",
    defaultLabel: "Ř_Default Settings_ů",
    realtimeLabel: "Ř_Can Realtime Show_ů",
    computing: "Ř_computing..._ů",
    latitudeLabel: "Ř_Latitude_ů",
    longitudeLabel: "Ř_Longitude_ů"
});
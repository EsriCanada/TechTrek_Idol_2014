﻿define({
    signin: "ã_Sign In_Ç",
    signout: "ã_Sign Out_Ç",
    about: "ã_About_Ç",
    signInTo: "ã_Sign in to_Ç"
});

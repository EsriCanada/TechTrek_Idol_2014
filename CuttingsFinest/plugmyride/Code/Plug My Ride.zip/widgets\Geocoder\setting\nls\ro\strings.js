﻿define({

    placeholder: "Ă_Placeholder Text_ș",
    url: "Ă_Geocoder URL_ș",
    name: "Ă_Geocoder Name_ș",
    singleLineFieldName: "Ă_SingleLineFieldName_ș",
    portalConnectionError: 'Ă_Can not get the configuratin of geocode from protal_ș',
    actions: "Ă_Actions_ș",
    warning: "Ă_Incorrect Service_ș",
    instruction: "Ă_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ș
    Ă_"You can also reorder,configure,or delete your geocoders bleow._ș",
    add: "Ă_Add Geocoder_ș",
    edit: "Ă_Edit Geocoder_ș",
    ok: "Ă_OK_ș",
    cancel: "Ă_Cancel_ș",
    REPEATING_ERROR: "Ă_The fllowing fields are repeated:_ș "
});
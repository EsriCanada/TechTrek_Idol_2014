﻿define({

    hintMessage: "Ă_Click map to get coordinate_ș",
    defaultLabel: "Ă_Default Settings_ș",
    realtimeLabel: "Ă_Can Realtime Show_ș",
    computing: "Ă_computing..._ș",
    latitudeLabel: "Ă_Latitude_ș",
    longitudeLabel: "Ă_Longitude_ș"
});
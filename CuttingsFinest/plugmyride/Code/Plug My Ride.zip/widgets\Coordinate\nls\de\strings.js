﻿define({

    hintMessage: "ä_Click map to get coordinate_Ü",
    defaultLabel: "ä_Default Settings_Ü",
    realtimeLabel: "ä_Can Realtime Show_Ü",
    computing: "ä_computing..._Ü",
    latitudeLabel: "ä_Latitude_Ü",
    longitudeLabel: "ä_Longitude_Ü"
});
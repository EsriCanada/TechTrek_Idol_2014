﻿define({
    titleBasemap: 'Į_Base maps_š',
    titleLayers: 'Į_Operational Layers_š',
    labelLayer: 'Į_Layer Name_š',
    itemZoomTo: 'Į_Zoom to_š',
    itemTransparency: 'Į_Transparency_š',
    itemTransparent: 'Į_Transparent_š',
    itemOpaque: 'Į_Opaque_š',
    itemMoveUp: 'Į_Move up_š',
    itemMoveDown: 'Į_Move down_š',
    itemDesc: 'Į_Description_š',
    itemDownload: 'Į_Download_š',
    itemToAttributeTable: 'Į_Open attribute table_š'
});

﻿define({

    hintMessage: "ı_Click map to get coordinate_İ",
    defaultLabel: "ı_Default Settings_İ",
    realtimeLabel: "ı_Can Realtime Show_İ",
    computing: "ı_computing..._İ",
    latitudeLabel: "ı_Latitude_İ",
    longitudeLabel: "ı_Longitude_İ"
});
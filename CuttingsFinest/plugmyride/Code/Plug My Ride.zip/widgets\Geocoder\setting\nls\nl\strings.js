﻿define({

    placeholder: "Ĳ_Placeholder Text_ä",
    url: "Ĳ_Geocoder URL_ä",
    name: "Ĳ_Geocoder Name_ä",
    singleLineFieldName: "Ĳ_SingleLineFieldName_ä",
    portalConnectionError: 'Ĳ_Can not get the configuratin of geocode from protal_ä',
    actions: "Ĳ_Actions_ä",
    warning: "Ĳ_Incorrect Service_ä",
    instruction: "Ĳ_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ä
    Ĳ_"You can also reorder,configure,or delete your geocoders bleow._ä",
    add: "Ĳ_Add Geocoder_ä",
    edit: "Ĳ_Edit Geocoder_ä",
    ok: "Ĳ_OK_ä",
    cancel: "Ĳ_Cancel_ä",
    REPEATING_ERROR: "Ĳ_The fllowing fields are repeated:_ä "
});
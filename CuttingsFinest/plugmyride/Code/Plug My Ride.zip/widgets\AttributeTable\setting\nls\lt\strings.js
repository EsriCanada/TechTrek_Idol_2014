﻿define({
    label: "Į_Layer_š",
    show: "Į_Show_š",
    actions: "Į_Selection Symbol_š",
    field: "Į_Field_š",
    alias: "Į_Alias_š",
    visible: "Į_Visible_š",
    linkField: "Į_LinkField_š",
    noLayers: "Į_No feature layers available_š",
    back: "Į_Back_š",
    exportCSV: "Į_Export to CSV_š",
    restore: "Į_Restore to default value_š",
    ok: "Į_OK_š",
    result: "Į_Save successfully_š",
    warning: "Į_Check to show this layer in table firstly._š"
});
﻿define({
    titleBasemap: 'å_Base maps_ø',
    titleLayers: 'å_Operational Layers_ø',
    labelLayer: 'å_Layer Name_ø',
    itemZoomTo: 'å_Zoom to_ø',
    itemTransparency: 'å_Transparency_ø',
    itemTransparent: 'å_Transparent_ø',
    itemOpaque: 'å_Opaque_ø',
    itemMoveUp: 'å_Move up_ø',
    itemMoveDown: 'å_Move down_ø',
    itemDesc: 'å_Description_ø',
    itemDownload: 'å_Download_ø',
    itemToAttributeTable: 'å_Open attribute table_ø'
});

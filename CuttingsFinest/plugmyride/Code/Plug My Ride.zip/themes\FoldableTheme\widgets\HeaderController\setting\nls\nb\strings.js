﻿define({
    group: "å_Name_ø",
    openAll: "å_Open All in Panel_ø",
    dropDown: "å_Show in Drop-down Menu_ø",
    noGroup: "å_There is no widget group set._ø",
    groupSetLabel: "å_Set widget groups properties_ø"
});
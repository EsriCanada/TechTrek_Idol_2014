﻿define({
    showLegend: "כן_Show Legend_ש"
});
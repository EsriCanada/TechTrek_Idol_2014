﻿define({
    signin: "Ж_Sign In_Я",
    signout: "Ж_Sign Out_Я",
    about: "Ж_About_Я",
    signInTo: "Ж_Sign in to_Я"
});

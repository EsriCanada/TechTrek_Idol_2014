﻿define({

    placeholder: "é_Placeholder Text_È",
    url: "é_Geocoder URL_È",
    name: "é_Geocoder Name_È",
    singleLineFieldName: "é_SingleLineFieldName_È",
    portalConnectionError: 'é_Can not get the configuratin of geocode from protal_È',
    actions: "é_Actions_È",
    warning: "é_Incorrect Service_È",
    instruction: "é_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_È
    é_"You can also reorder,configure,or delete your geocoders bleow._È",
    add: "é_Add Geocoder_È",
    edit: "é_Edit Geocoder_È",
    ok: "é_OK_È",
    cancel: "é_Cancel_È",
    REPEATING_ERROR: "é_The fllowing fields are repeated:_È "
});
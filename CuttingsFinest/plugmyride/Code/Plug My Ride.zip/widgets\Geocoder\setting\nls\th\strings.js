﻿define({

    placeholder: "ก้_Placeholder Text_ษฺ",
    url: "ก้_Geocoder URL_ษฺ",
    name: "ก้_Geocoder Name_ษฺ",
    singleLineFieldName: "ก้_SingleLineFieldName_ษฺ",
    portalConnectionError: 'ก้_Can not get the configuratin of geocode from protal_ษฺ',
    actions: "ก้_Actions_ษฺ",
    warning: "ก้_Incorrect Service_ษฺ",
    instruction: "ก้_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ษฺ
    ก้_"You can also reorder,configure,or delete your geocoders bleow._ษฺ",
    add: "ก้_Add Geocoder_ษฺ",
    edit: "ก้_Edit Geocoder_ษฺ",
    ok: "ก้_OK_ษฺ",
    cancel: "ก้_Cancel_ษฺ",
    REPEATING_ERROR: "ก้_The fllowing fields are repeated:_ษฺ "
});
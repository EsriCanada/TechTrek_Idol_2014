﻿define({
    titleBasemap: 'æ_Base maps_Â',
    titleLayers: 'æ_Operational Layers_Â',
    labelLayer: 'æ_Layer Name_Â',
    itemZoomTo: 'æ_Zoom to_Â',
    itemTransparency: 'æ_Transparency_Â',
    itemTransparent: 'æ_Transparent_Â',
    itemOpaque: 'æ_Opaque_Â',
    itemMoveUp: 'æ_Move up_Â',
    itemMoveDown: 'æ_Move down_Â',
    itemDesc: 'æ_Description_Â',
    itemDownload: 'æ_Download_Â',
    itemToAttributeTable: 'æ_Open attribute table_Â'
});

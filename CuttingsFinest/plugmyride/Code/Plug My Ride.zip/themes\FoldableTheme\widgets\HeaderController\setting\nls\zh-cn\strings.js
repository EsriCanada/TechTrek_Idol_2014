﻿define({
    group: "试_Name_验",
    openAll: "试_Open All in Panel_验",
    dropDown: "试_Show in Drop-down Menu_验",
    noGroup: "试_There is no widget group set._验",
    groupSetLabel: "试_Set widget groups properties_验"
});
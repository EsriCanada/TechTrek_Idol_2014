﻿define({
    label: "å_Layer_ø",
    show: "å_Show_ø",
    actions: "å_Selection Symbol_ø",
    field: "å_Field_ø",
    alias: "å_Alias_ø",
    visible: "å_Visible_ø",
    linkField: "å_LinkField_ø",
    noLayers: "å_No feature layers available_ø",
    back: "å_Back_ø",
    exportCSV: "å_Export to CSV_ø",
    restore: "å_Restore to default value_ø",
    ok: "å_OK_ø",
    result: "å_Save successfully_ø",
    warning: "å_Check to show this layer in table firstly._ø"
});
﻿define({

    hintMessage: "Ĳ_Click map to get coordinate_ä",
    defaultLabel: "Ĳ_Default Settings_ä",
    realtimeLabel: "Ĳ_Can Realtime Show_ä",
    computing: "Ĳ_computing..._ä",
    latitudeLabel: "Ĳ_Latitude_ä",
    longitudeLabel: "Ĳ_Longitude_ä"
});
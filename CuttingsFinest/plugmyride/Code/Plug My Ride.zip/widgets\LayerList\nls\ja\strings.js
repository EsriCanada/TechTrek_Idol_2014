﻿define({
    titleBasemap: '須_Base maps_鷗',
    titleLayers: '須_Operational Layers_鷗',
    labelLayer: '須_Layer Name_鷗',
    itemZoomTo: '須_Zoom to_鷗',
    itemTransparency: '須_Transparency_鷗',
    itemTransparent: '須_Transparent_鷗',
    itemOpaque: '須_Opaque_鷗',
    itemMoveUp: '須_Move up_鷗',
    itemMoveDown: '須_Move down_鷗',
    itemDesc: '須_Description_鷗',
    itemDownload: '須_Download_鷗',
    itemToAttributeTable: '須_Open attribute table_鷗'
});

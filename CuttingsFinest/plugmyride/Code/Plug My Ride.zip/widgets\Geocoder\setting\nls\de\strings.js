﻿define({

    placeholder: "ä_Placeholder Text_Ü",
    url: "ä_Geocoder URL_Ü",
    name: "ä_Geocoder Name_Ü",
    singleLineFieldName: "ä_SingleLineFieldName_Ü",
    portalConnectionError: 'ä_Can not get the configuratin of geocode from protal_Ü',
    actions: "ä_Actions_Ü",
    warning: "ä_Incorrect Service_Ü",
    instruction: "ä_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_Ü
    ä_"You can also reorder,configure,or delete your geocoders bleow._Ü",
    add: "ä_Add Geocoder_Ü",
    edit: "ä_Edit Geocoder_Ü",
    ok: "ä_OK_Ü",
    cancel: "ä_Cancel_Ü",
    REPEATING_ERROR: "ä_The fllowing fields are repeated:_Ü "
});
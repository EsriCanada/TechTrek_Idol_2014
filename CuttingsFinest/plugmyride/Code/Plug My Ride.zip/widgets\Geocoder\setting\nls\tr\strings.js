﻿define({

    placeholder: "ı_Placeholder Text_İ",
    url: "ı_Geocoder URL_İ",
    name: "ı_Geocoder Name_İ",
    singleLineFieldName: "ı_SingleLineFieldName_İ",
    portalConnectionError: 'ı_Can not get the configuratin of geocode from protal_İ',
    actions: "ı_Actions_İ",
    warning: "ı_Incorrect Service_İ",
    instruction: "ı_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_İ
    ı_"You can also reorder,configure,or delete your geocoders bleow._İ",
    add: "ı_Add Geocoder_İ",
    edit: "ı_Edit Geocoder_İ",
    ok: "ı_OK_İ",
    cancel: "ı_Cancel_İ",
    REPEATING_ERROR: "ı_The fllowing fields are repeated:_İ "
});
﻿define({
	signin: "试_Sign In_验",
	signout: "试_Sign Out_验",
	about: "试_About_验",
	signInTo: "试_Sign in to_验",
	cantSignOutTip: "试_This function is N/A in preview mode._验"
});
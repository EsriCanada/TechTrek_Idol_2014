﻿define({
    group: "Å_Name_ö",
    openAll: "Å_Open All in Panel_ö",
    dropDown: "Å_Show in Drop-down Menu_ö",
    noGroup: "Å_There is no widget group set._ö",
    groupSetLabel: "Å_Set widget groups properties_ö"
});
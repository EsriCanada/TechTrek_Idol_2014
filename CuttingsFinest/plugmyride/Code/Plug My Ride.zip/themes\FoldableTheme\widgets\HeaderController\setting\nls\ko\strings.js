﻿define({
    group: "한_Name_빠",
    openAll: "한_Open All in Panel_빠",
    dropDown: "한_Show in Drop-down Menu_빠",
    noGroup: "한_There is no widget group set._빠",
    groupSetLabel: "한_Set widget groups properties_빠"
});
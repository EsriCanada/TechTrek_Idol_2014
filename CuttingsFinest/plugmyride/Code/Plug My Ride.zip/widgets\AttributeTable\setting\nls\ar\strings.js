﻿define({
    label: "بيت_Layer_لاحقة",
    show: "بيت_Show_لاحقة",
    actions: "بيت_Selection Symbol_لاحقة",
    field: "بيت_Field_لاحقة",
    alias: "بيت_Alias_لاحقة",
    visible: "بيت_Visible_لاحقة",
    linkField: "بيت_LinkField_لاحقة",
    noLayers: "بيت_No feature layers available_لاحقة",
    back: "بيت_Back_لاحقة",
    exportCSV: "بيت_Export to CSV_لاحقة",
    restore: "بيت_Restore to default value_لاحقة",
    ok: "بيت_OK_لاحقة",
    result: "بيت_Save successfully_لاحقة",
    warning: "بيت_Check to show this layer in table firstly._لاحقة"
});
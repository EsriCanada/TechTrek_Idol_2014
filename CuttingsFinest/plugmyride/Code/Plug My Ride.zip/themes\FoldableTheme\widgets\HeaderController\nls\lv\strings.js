﻿define({
    signin: "ķ_Sign In_ū",
    signout: "ķ_Sign Out_ū",
    about: "ķ_About_ū",
    signInTo: "ķ_Sign in to_ū"
});

﻿define({

    placeholder: "כן_Placeholder Text_ש",
    url: "כן_Geocoder URL_ש",
    name: "כן_Geocoder Name_ש",
    singleLineFieldName: "כן_SingleLineFieldName_ש",
    portalConnectionError: 'כן_Can not get the configuratin of geocode from protal_ש',
    actions: "כן_Actions_ש",
    warning: "כן_Incorrect Service_ש",
    instruction: "כן_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ש
    כן_"You can also reorder,configure,or delete your geocoders bleow._ש",
    add: "כן_Add Geocoder_ש",
    edit: "כן_Edit Geocoder_ש",
    ok: "כן_OK_ש",
    cancel: "כן_Cancel_ש",
    REPEATING_ERROR: "כן_The fllowing fields are repeated:_ש "
});
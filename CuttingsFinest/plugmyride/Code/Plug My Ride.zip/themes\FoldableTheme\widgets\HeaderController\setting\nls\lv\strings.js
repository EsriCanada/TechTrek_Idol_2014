﻿define({
    group: "ķ_Name_ū",
    openAll: "ķ_Open All in Panel_ū",
    dropDown: "ķ_Show in Drop-down Menu_ū",
    noGroup: "ķ_There is no widget group set._ū",
    groupSetLabel: "ķ_Set widget groups properties_ū"
});
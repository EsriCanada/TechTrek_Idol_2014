﻿define({
    group: "Š_Name_ä",
    openAll: "Š_Open All in Panel_ä",
    dropDown: "Š_Show in Drop-down Menu_ä",
    noGroup: "Š_There is no widget group set._ä",
    groupSetLabel: "Š_Set widget groups properties_ä"
});
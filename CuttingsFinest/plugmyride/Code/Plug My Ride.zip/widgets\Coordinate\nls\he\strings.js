﻿define({

    hintMessage: "כן_Click map to get coordinate_ש",
    defaultLabel: "כן_Default Settings_ש",
    realtimeLabel: "כן_Can Realtime Show_ש",
    computing: "כן_computing..._ש",
    latitudeLabel: "כן_Latitude_ש",
    longitudeLabel: "כן_Longitude_ש"
});
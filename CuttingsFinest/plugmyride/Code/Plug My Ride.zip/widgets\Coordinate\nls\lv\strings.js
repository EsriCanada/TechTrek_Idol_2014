﻿define({

    hintMessage: "ķ_Click map to get coordinate_ū",
    defaultLabel: "ķ_Default Settings_ū",
    realtimeLabel: "ķ_Can Realtime Show_ū",
    computing: "ķ_computing..._ū",
    latitudeLabel: "ķ_Latitude_ū",
    longitudeLabel: "ķ_Longitude_ū"
});
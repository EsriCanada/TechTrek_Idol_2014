﻿define({
    label: "Ж_Layer_Я",
    show: "Ж_Show_Я",
    actions: "Ж_Selection Symbol_Я",
    field: "Ж_Field_Я",
    alias: "Ж_Alias_Я",
    visible: "Ж_Visible_Я",
    linkField: "Ж_LinkField_Я",
    noLayers: "Ж_No feature layers available_Я",
    back: "Ж_Back_Я",
    exportCSV: "Ж_Export to CSV_Я",
    restore: "Ж_Restore to default value_Я",
    ok: "Ж_OK_Я",
    result: "Ж_Save successfully_Я",
    warning: "Ж_Check to show this layer in table firstly._Я"
});
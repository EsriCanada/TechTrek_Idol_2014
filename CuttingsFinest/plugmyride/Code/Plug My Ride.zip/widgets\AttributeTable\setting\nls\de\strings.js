﻿define({
    label: "ä_Layer_Ü",
    show: "ä_Show_Ü",
    actions: "ä_Selection Symbol_Ü",
    field: "ä_Field_Ü",
    alias: "ä_Alias_Ü",
    visible: "ä_Visible_Ü",
    linkField: "ä_LinkField_Ü",
    noLayers: "ä_No feature layers available_Ü",
    back: "ä_Back_Ü",
    exportCSV: "ä_Export to CSV_Ü",
    restore: "ä_Restore to default value_Ü",
    ok: "ä_OK_Ü",
    result: "ä_Save successfully_Ü",
    warning: "ä_Check to show this layer in table firstly._Ü"
});
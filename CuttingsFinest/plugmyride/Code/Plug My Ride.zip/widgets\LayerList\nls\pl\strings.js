﻿define({
    titleBasemap: 'ł_Base maps_ą',
    titleLayers: 'ł_Operational Layers_ą',
    labelLayer: 'ł_Layer Name_ą',
    itemZoomTo: 'ł_Zoom to_ą',
    itemTransparency: 'ł_Transparency_ą',
    itemTransparent: 'ł_Transparent_ą',
    itemOpaque: 'ł_Opaque_ą',
    itemMoveUp: 'ł_Move up_ą',
    itemMoveDown: 'ł_Move down_ą',
    itemDesc: 'ł_Description_ą',
    itemDownload: 'ł_Download_ą',
    itemToAttributeTable: 'ł_Open attribute table_ą'
});

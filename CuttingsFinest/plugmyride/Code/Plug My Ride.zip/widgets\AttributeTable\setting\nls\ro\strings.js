﻿define({
    label: "Ă_Layer_ș",
    show: "Ă_Show_ș",
    actions: "Ă_Selection Symbol_ș",
    field: "Ă_Field_ș",
    alias: "Ă_Alias_ș",
    visible: "Ă_Visible_ș",
    linkField: "Ă_LinkField_ș",
    noLayers: "Ă_No feature layers available_ș",
    back: "Ă_Back_ș",
    exportCSV: "Ă_Export to CSV_ș",
    restore: "Ă_Restore to default value_ș",
    ok: "Ă_OK_ș",
    result: "Ă_Save successfully_ș",
    warning: "Ă_Check to show this layer in table firstly._ș"
});
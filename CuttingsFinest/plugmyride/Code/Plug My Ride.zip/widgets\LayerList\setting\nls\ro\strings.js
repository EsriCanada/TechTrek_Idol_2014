﻿define({
    showLegend: "Ă_Show Legend_ș"
});
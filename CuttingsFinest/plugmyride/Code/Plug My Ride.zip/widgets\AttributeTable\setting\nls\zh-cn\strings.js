﻿define({
    label: "图层",
    show: "显示",
    actions: "选中要素符号",
    field: "字段",
    alias: "别名",
    visible: "可见",
    linkField: "链接字段",
    noLayers: "没有可用图层",
    back: "后退",
    exportCSV: "允许导出CSV为文件",
    restore: "恢复成默认值",
    ok: "确定",
    result: "保存成功",
    warning: "将此图层显示在表格最前端"
  });
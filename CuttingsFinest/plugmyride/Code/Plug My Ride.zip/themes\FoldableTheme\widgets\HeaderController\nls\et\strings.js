﻿define({
    signin: "Š_Sign In_ä",
    signout: "Š_Sign Out_ä",
    about: "Š_About_ä",
    signInTo: "Š_Sign in to_ä"
});

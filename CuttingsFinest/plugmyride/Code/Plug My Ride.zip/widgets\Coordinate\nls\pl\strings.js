﻿define({

    hintMessage: "ł_Click map to get coordinate_ą",
    defaultLabel: "ł_Default Settings_ą",
    realtimeLabel: "ł_Can Realtime Show_ą",
    computing: "ł_computing..._ą",
    latitudeLabel: "ł_Latitude_ą",
    longitudeLabel: "ł_Longitude_ą"
});
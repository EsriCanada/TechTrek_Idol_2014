﻿define({
    label: "ก้_Layer_ษฺ",
    show: "ก้_Show_ษฺ",
    actions: "ก้_Selection Symbol_ษฺ",
    field: "ก้_Field_ษฺ",
    alias: "ก้_Alias_ษฺ",
    visible: "ก้_Visible_ษฺ",
    linkField: "ก้_LinkField_ษฺ",
    noLayers: "ก้_No feature layers available_ษฺ",
    back: "ก้_Back_ษฺ",
    exportCSV: "ก้_Export to CSV_ษฺ",
    restore: "ก้_Restore to default value_ษฺ",
    ok: "ก้_OK_ษฺ",
    result: "ก้_Save successfully_ษฺ",
    warning: "ก้_Check to show this layer in table firstly._ษฺ"
});
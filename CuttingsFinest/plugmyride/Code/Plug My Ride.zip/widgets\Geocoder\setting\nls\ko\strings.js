﻿define({

    placeholder: "한_Placeholder Text_빠",
    url: "한_Geocoder URL_빠",
    name: "한_Geocoder Name_빠",
    singleLineFieldName: "한_SingleLineFieldName_빠",
    portalConnectionError: '한_Can not get the configuratin of geocode from protal_빠',
    actions: "한_Actions_빠",
    warning: "한_Incorrect Service_빠",
    instruction: "한_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_빠
    한_"You can also reorder,configure,or delete your geocoders bleow._빠",
    add: "한_Add Geocoder_빠",
    edit: "한_Edit Geocoder_빠",
    ok: "한_OK_빠",
    cancel: "한_Cancel_빠",
    REPEATING_ERROR: "한_The fllowing fields are repeated:_빠 "
});
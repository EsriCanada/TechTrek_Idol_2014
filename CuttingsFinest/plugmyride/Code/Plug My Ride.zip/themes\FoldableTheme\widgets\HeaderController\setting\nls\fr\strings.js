﻿define({
    group: "æ_Name_Â",
    openAll: "æ_Open All in Panel_Â",
    dropDown: "æ_Show in Drop-down Menu_Â",
    noGroup: "æ_There is no widget group set._Â",
    groupSetLabel: "æ_Set widget groups properties_Â"
});
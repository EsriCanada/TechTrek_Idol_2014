﻿define({
    group: "כן_Name_ש",
    openAll: "כן_Open All in Panel_ש",
    dropDown: "כן_Show in Drop-down Menu_ש",
    noGroup: "כן_There is no widget group set._ש",
    groupSetLabel: "כן_Set widget groups properties_ש"
});
﻿define({
    label: "כן_Layer_ש",
    show: "כן_Show_ש",
    actions: "כן_Selection Symbol_ש",
    field: "כן_Field_ש",
    alias: "כן_Alias_ש",
    visible: "כן_Visible_ש",
    linkField: "כן_LinkField_ש",
    noLayers: "כן_No feature layers available_ש",
    back: "כן_Back_ש",
    exportCSV: "כן_Export to CSV_ש",
    restore: "כן_Restore to default value_ש",
    ok: "כן_OK_ש",
    result: "כן_Save successfully_ש",
    warning: "כן_Check to show this layer in table firstly._ש"
});
﻿define({

    placeholder: "Į_Placeholder Text_š",
    url: "Į_Geocoder URL_š",
    name: "Į_Geocoder Name_š",
    singleLineFieldName: "Į_SingleLineFieldName_š",
    portalConnectionError: 'Į_Can not get the configuratin of geocode from protal_š',
    actions: "Į_Actions_š",
    warning: "Į_Incorrect Service_š",
    instruction: "Į_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_š
    Į_"You can also reorder,configure,or delete your geocoders bleow._š",
    add: "Į_Add Geocoder_š",
    edit: "Į_Edit Geocoder_š",
    ok: "Į_OK_š",
    cancel: "Į_Cancel_š",
    REPEATING_ERROR: "Į_The fllowing fields are repeated:_š "
});
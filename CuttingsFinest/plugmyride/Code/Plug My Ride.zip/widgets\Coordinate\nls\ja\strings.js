﻿define({

    hintMessage: "須_Click map to get coordinate_鷗",
    defaultLabel: "須_Default Settings_鷗",
    realtimeLabel: "須_Can Realtime Show_鷗",
    computing: "須_computing..._鷗",
    latitudeLabel: "須_Latitude_鷗",
    longitudeLabel: "須_Longitude_鷗"
});
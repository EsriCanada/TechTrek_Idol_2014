﻿define({
    group: "須_Name_鷗",
    openAll: "須_Open All in Panel_鷗",
    dropDown: "須_Show in Drop-down Menu_鷗",
    noGroup: "須_There is no widget group set._鷗",
    groupSetLabel: "須_Set widget groups properties_鷗"
});
﻿define({
    group: "Ř_Name_ů",
    openAll: "Ř_Open All in Panel_ů",
    dropDown: "Ř_Show in Drop-down Menu_ů",
    noGroup: "Ř_There is no widget group set._ů",
    groupSetLabel: "Ř_Set widget groups properties_ů"
});
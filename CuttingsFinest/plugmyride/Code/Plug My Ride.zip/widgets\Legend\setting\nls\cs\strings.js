﻿define({
    arrangement: "Ř_Arrangement_ů",
    autoUpdate: "Ř_Auto Update_ů",
    respectCurrentMapScale: "Ř_Respect Current Map Scale_ů"
});
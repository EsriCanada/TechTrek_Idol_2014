﻿define({
    signin: "é_Sign In_È",
    signout: "é_Sign Out_È",
    about: "é_About_È",
    signInTo: "é_Sign in to_È"
});

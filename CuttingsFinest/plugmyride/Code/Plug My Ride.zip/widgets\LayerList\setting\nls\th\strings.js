﻿define({
    showLegend: "ก้_Show Legend_ษฺ"
});
﻿define({
    signin: "須_Sign In_鷗",
    signout: "須_Sign Out_鷗",
    about: "須_About_鷗",
    signInTo: "須_Sign in to_鷗"
});

﻿define({
    group: "ã_Name_Ç",
    openAll: "ã_Open All in Panel_Ç",
    dropDown: "ã_Show in Drop-down Menu_Ç",
    noGroup: "ã_There is no widget group set._Ç",
    groupSetLabel: "ã_Set widget groups properties_Ç"
});
﻿define({
    group: "ł_Name_ą",
    openAll: "ł_Open All in Panel_ą",
    dropDown: "ł_Show in Drop-down Menu_ą",
    noGroup: "ł_There is no widget group set._ą",
    groupSetLabel: "ł_Set widget groups properties_ą"
});
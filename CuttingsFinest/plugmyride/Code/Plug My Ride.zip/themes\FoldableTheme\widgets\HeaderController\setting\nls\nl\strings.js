﻿define({
    group: "Ĳ_Name_ä",
    openAll: "Ĳ_Open All in Panel_ä",
    dropDown: "Ĳ_Show in Drop-down Menu_ä",
    noGroup: "Ĳ_There is no widget group set._ä",
    groupSetLabel: "Ĳ_Set widget groups properties_ä"
});
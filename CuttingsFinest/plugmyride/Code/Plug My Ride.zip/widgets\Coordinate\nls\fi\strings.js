﻿define({

    hintMessage: "Å_Click map to get coordinate_ö",
    defaultLabel: "Å_Default Settings_ö",
    realtimeLabel: "Å_Can Realtime Show_ö",
    computing: "Å_computing..._ö",
    latitudeLabel: "Å_Latitude_ö",
    longitudeLabel: "Å_Longitude_ö"
});
﻿define({
    showLegend: "Å_Show Legend_ö"
});
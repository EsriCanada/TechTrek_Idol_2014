﻿define({
    showLegend: "بيت_Show Legend_لاحقة"
});
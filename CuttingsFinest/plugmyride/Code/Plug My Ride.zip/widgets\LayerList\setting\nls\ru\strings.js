﻿define({
    showLegend: "Ж_Show Legend_Я"
});
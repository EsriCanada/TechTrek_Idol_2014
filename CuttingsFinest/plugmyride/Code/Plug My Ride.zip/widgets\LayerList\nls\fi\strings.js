﻿define({
    titleBasemap: 'Å_Base maps_ö',
    titleLayers: 'Å_Operational Layers_ö',
    labelLayer: 'Å_Layer Name_ö',
    itemZoomTo: 'Å_Zoom to_ö',
    itemTransparency: 'Å_Transparency_ö',
    itemTransparent: 'Å_Transparent_ö',
    itemOpaque: 'Å_Opaque_ö',
    itemMoveUp: 'Å_Move up_ö',
    itemMoveDown: 'Å_Move down_ö',
    itemDesc: 'Å_Description_ö',
    itemDownload: 'Å_Download_ö',
    itemToAttributeTable: 'Å_Open attribute table_ö'
});

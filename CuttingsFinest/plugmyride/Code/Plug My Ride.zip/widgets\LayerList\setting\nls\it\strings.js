﻿define({
    showLegend: "é_Show Legend_È"
});
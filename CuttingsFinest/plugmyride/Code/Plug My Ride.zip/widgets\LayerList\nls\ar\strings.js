﻿define({
    titleBasemap: 'بيت_Base maps_لاحقة',
    titleLayers: 'بيت_Operational Layers_لاحقة',
    labelLayer: 'بيت_Layer Name_لاحقة',
    itemZoomTo: 'بيت_Zoom to_لاحقة',
    itemTransparency: 'بيت_Transparency_لاحقة',
    itemTransparent: 'بيت_Transparent_لاحقة',
    itemOpaque: 'بيت_Opaque_لاحقة',
    itemMoveUp: 'بيت_Move up_لاحقة',
    itemMoveDown: 'بيت_Move down_لاحقة',
    itemDesc: 'بيت_Description_لاحقة',
    itemDownload: 'بيت_Download_لاحقة',
    itemToAttributeTable: 'بيت_Open attribute table_لاحقة'
});

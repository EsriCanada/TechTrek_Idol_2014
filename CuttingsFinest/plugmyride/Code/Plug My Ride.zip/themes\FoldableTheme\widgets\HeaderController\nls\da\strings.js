﻿define({
    signin: "ø_Sign In_å",
    signout: "ø_Sign Out_å",
    about: "ø_About_å",
    signInTo: "ø_Sign in to_å"
});

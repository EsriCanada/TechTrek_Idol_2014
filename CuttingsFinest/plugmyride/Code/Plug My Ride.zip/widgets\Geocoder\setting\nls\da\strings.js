﻿define({

    placeholder: "ø_Placeholder Text_å",
    url: "ø_Geocoder URL_å",
    name: "ø_Geocoder Name_å",
    singleLineFieldName: "ø_SingleLineFieldName_å",
    portalConnectionError: 'ø_Can not get the configuratin of geocode from protal_å',
    actions: "ø_Actions_å",
    warning: "ø_Incorrect Service_å",
    instruction: "ø_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_å
    ø_"You can also reorder,configure,or delete your geocoders bleow._å",
    add: "ø_Add Geocoder_å",
    edit: "ø_Edit Geocoder_å",
    ok: "ø_OK_å",
    cancel: "ø_Cancel_å",
    REPEATING_ERROR: "ø_The fllowing fields are repeated:_å "
});
﻿define({

    hintMessage: "ã_Click map to get coordinate_Ç",
    defaultLabel: "ã_Default Settings_Ç",
    realtimeLabel: "ã_Can Realtime Show_Ç",
    computing: "ã_computing..._Ç",
    latitudeLabel: "ã_Latitude_Ç",
    longitudeLabel: "ã_Longitude_Ç"
});
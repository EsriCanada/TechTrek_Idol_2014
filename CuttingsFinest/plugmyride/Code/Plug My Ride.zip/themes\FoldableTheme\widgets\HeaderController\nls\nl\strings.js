﻿define({
    signin: "Ĳ_Sign In_ä",
    signout: "Ĳ_Sign Out_ä",
    about: "Ĳ_About_ä",
    signInTo: "Ĳ_Sign in to_ä"
});

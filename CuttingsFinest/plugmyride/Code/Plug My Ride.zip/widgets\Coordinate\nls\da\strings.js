﻿define({

    hintMessage: "ø_Click map to get coordinate_å",
    defaultLabel: "ø_Default Settings_å",
    realtimeLabel: "ø_Can Realtime Show_å",
    computing: "ø_computing..._å",
    latitudeLabel: "ø_Latitude_å",
    longitudeLabel: "ø_Longitude_å"
});
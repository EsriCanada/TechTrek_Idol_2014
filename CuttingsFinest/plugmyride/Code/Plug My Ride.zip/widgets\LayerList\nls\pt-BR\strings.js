﻿define({
    titleBasemap: 'ã_Base maps_Ç',
    titleLayers: 'ã_Operational Layers_Ç',
    labelLayer: 'ã_Layer Name_Ç',
    itemZoomTo: 'ã_Zoom to_Ç',
    itemTransparency: 'ã_Transparency_Ç',
    itemTransparent: 'ã_Transparent_Ç',
    itemOpaque: 'ã_Opaque_Ç',
    itemMoveUp: 'ã_Move up_Ç',
    itemMoveDown: 'ã_Move down_Ç',
    itemDesc: 'ã_Description_Ç',
    itemDownload: 'ã_Download_Ç',
    itemToAttributeTable: 'ã_Open attribute table_Ç'
});

﻿define({

    hintMessage: "Ж_Click map to get coordinate_Я",
    defaultLabel: "Ж_Default Settings_Я",
    realtimeLabel: "Ж_Can Realtime Show_Я",
    computing: "Ж_computing..._Я",
    latitudeLabel: "Ж_Latitude_Я",
    longitudeLabel: "Ж_Longitude_Я"
});
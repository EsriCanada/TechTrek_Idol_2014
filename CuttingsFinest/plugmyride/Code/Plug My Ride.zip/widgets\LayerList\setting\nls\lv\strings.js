﻿define({
    showLegend: "ķ_Show Legend_ū"
});
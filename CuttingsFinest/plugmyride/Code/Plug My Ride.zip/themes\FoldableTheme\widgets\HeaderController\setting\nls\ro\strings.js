﻿define({
    group: "Ă_Name_ș",
    openAll: "Ă_Open All in Panel_ș",
    dropDown: "Ă_Show in Drop-down Menu_ș",
    noGroup: "Ă_There is no widget group set._ș",
    groupSetLabel: "Ă_Set widget groups properties_ș"
});
﻿define({
    signin: "å_Sign In_ø",
    signout: "å_Sign Out_ø",
    about: "å_About_ø",
    signInTo: "å_Sign in to_ø"
});

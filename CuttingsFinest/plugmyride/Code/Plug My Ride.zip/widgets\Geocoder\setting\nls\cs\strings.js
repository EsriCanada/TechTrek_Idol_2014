﻿define({

    placeholder: "Ř_Placeholder Text_ů",
    url: "Ř_Geocoder URL_ů",
    name: "Ř_Geocoder Name_ů",
    singleLineFieldName: "Ř_SingleLineFieldName_ů",
    portalConnectionError: 'Ř_Can not get the configuratin of geocode from protal_ů',
    actions: "Ř_Actions_ů",
    warning: "Ř_Incorrect Service_ů",
    instruction: "Ř_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ů
    Ř_"You can also reorder,configure,or delete your geocoders bleow._ů",
    add: "Ř_Add Geocoder_ů",
    edit: "Ř_Edit Geocoder_ů",
    ok: "Ř_OK_ů",
    cancel: "Ř_Cancel_ů",
    REPEATING_ERROR: "Ř_The fllowing fields are repeated:_ů "
});
﻿define({

    placeholder: "須_Placeholder Text_鷗",
    url: "須_Geocoder URL_鷗",
    name: "須_Geocoder Name_鷗",
    singleLineFieldName: "須_SingleLineFieldName_鷗",
    portalConnectionError: '須_Can not get the configuratin of geocode from protal_鷗',
    actions: "須_Actions_鷗",
    warning: "須_Incorrect Service_鷗",
    instruction: "須_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_鷗
    須_"You can also reorder,configure,or delete your geocoders bleow._鷗",
    add: "須_Add Geocoder_鷗",
    edit: "須_Edit Geocoder_鷗",
    ok: "須_OK_鷗",
    cancel: "須_Cancel_鷗",
    REPEATING_ERROR: "須_The fllowing fields are repeated:_鷗 "
});
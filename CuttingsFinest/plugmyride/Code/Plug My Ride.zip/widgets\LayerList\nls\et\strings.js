﻿define({
    titleBasemap: 'Š_Base maps_ä',
    titleLayers: 'Š_Operational Layers_ä',
    labelLayer: 'Š_Layer Name_ä',
    itemZoomTo: 'Š_Zoom to_ä',
    itemTransparency: 'Š_Transparency_ä',
    itemTransparent: 'Š_Transparent_ä',
    itemOpaque: 'Š_Opaque_ä',
    itemMoveUp: 'Š_Move up_ä',
    itemMoveDown: 'Š_Move down_ä',
    itemDesc: 'Š_Description_ä',
    itemDownload: 'Š_Download_ä',
    itemToAttributeTable: 'Š_Open attribute table_ä'
});

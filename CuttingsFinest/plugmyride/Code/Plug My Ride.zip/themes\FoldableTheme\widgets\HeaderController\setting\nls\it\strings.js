﻿define({
    group: "é_Name_È",
    openAll: "é_Open All in Panel_È",
    dropDown: "é_Show in Drop-down Menu_È",
    noGroup: "é_There is no widget group set._È",
    groupSetLabel: "é_Set widget groups properties_È"
});
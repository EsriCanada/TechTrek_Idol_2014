﻿define({
    signin: "Ř_Sign In_ů",
    signout: "Ř_Sign Out_ů",
    about: "Ř_About_ů",
    signInTo: "Ř_Sign in to_ů"
});

﻿define({
    label: "Ĳ_Layer_ä",
    show: "Ĳ_Show_ä",
    actions: "Ĳ_Selection Symbol_ä",
    field: "Ĳ_Field_ä",
    alias: "Ĳ_Alias_ä",
    visible: "Ĳ_Visible_ä",
    linkField: "Ĳ_LinkField_ä",
    noLayers: "Ĳ_No feature layers available_ä",
    back: "Ĳ_Back_ä",
    exportCSV: "Ĳ_Export to CSV_ä",
    restore: "Ĳ_Restore to default value_ä",
    ok: "Ĳ_OK_ä",
    result: "Ĳ_Save successfully_ä",
    warning: "Ĳ_Check to show this layer in table firstly._ä"
});
﻿define({

    hintMessage: "å_Click map to get coordinate_ø",
    defaultLabel: "å_Default Settings_ø",
    realtimeLabel: "å_Can Realtime Show_ø",
    computing: "å_computing..._ø",
    latitudeLabel: "å_Latitude_ø",
    longitudeLabel: "å_Longitude_ø"
});
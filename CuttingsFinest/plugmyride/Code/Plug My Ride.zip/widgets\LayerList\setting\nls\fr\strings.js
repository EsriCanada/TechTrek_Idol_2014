﻿define({
    showLegend: "æ_Show Legend_Â"
});
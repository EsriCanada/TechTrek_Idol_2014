﻿define({

    placeholder: "ķ_Placeholder Text_ū",
    url: "ķ_Geocoder URL_ū",
    name: "ķ_Geocoder Name_ū",
    singleLineFieldName: "ķ_SingleLineFieldName_ū",
    portalConnectionError: 'ķ_Can not get the configuratin of geocode from protal_ū',
    actions: "ķ_Actions_ū",
    warning: "ķ_Incorrect Service_ū",
    instruction: "ķ_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ū
    ķ_"You can also reorder,configure,or delete your geocoders bleow._ū",
    add: "ķ_Add Geocoder_ū",
    edit: "ķ_Edit Geocoder_ū",
    ok: "ķ_OK_ū",
    cancel: "ķ_Cancel_ū",
    REPEATING_ERROR: "ķ_The fllowing fields are repeated:_ū "
});
﻿define({
    showLegend: "ã_Show Legend_Ç"
});
﻿define({
    titleBasemap: '한_Base maps_빠',
    titleLayers: '한_Operational Layers_빠',
    labelLayer: '한_Layer Name_빠',
    itemZoomTo: '한_Zoom to_빠',
    itemTransparency: '한_Transparency_빠',
    itemTransparent: '한_Transparent_빠',
    itemOpaque: '한_Opaque_빠',
    itemMoveUp: '한_Move up_빠',
    itemMoveDown: '한_Move down_빠',
    itemDesc: '한_Description_빠',
    itemDownload: '한_Download_빠',
    itemToAttributeTable: '한_Open attribute table_빠'
});

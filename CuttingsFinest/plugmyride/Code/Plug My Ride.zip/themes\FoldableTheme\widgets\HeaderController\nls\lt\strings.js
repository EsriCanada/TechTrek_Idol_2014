﻿define({
    signin: "Į_Sign In_š",
    signout: "Į_Sign Out_š",
    about: "Į_About_š",
    signInTo: "Į_Sign in to_š"
});

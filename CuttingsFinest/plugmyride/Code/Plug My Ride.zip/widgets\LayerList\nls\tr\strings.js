﻿define({
    titleBasemap: 'ı_Base maps_İ',
    titleLayers: 'ı_Operational Layers_İ',
    labelLayer: 'ı_Layer Name_İ',
    itemZoomTo: 'ı_Zoom to_İ',
    itemTransparency: 'ı_Transparency_İ',
    itemTransparent: 'ı_Transparent_İ',
    itemOpaque: 'ı_Opaque_İ',
    itemMoveUp: 'ı_Move up_İ',
    itemMoveDown: 'ı_Move down_İ',
    itemDesc: 'ı_Description_İ',
    itemDownload: 'ı_Download_İ',
    itemToAttributeTable: 'ı_Open attribute table_İ'
});

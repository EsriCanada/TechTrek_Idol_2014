﻿define({
    signin: "ł_Sign In_ą",
    signout: "ł_Sign Out_ą",
    about: "ł_About_ą",
    signInTo: "ł_Sign in to_ą"
});

﻿define({
    signin: "Ă_Sign In_ș",
    signout: "Ă_Sign Out_ș",
    about: "Ă_About_ș",
    signInTo: "Ă_Sign in to_ș"
});

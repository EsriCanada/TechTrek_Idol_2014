﻿define({
    showLegend: "ı_Show Legend_İ"
});
﻿define({
    showLegend: "ł_Show Legend_ą"
});
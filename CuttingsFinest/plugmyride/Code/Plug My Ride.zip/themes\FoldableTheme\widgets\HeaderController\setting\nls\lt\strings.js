﻿define({
    group: "Į_Name_š",
    openAll: "Į_Open All in Panel_š",
    dropDown: "Į_Show in Drop-down Menu_š",
    noGroup: "Į_There is no widget group set._š",
    groupSetLabel: "Į_Set widget groups properties_š"
});
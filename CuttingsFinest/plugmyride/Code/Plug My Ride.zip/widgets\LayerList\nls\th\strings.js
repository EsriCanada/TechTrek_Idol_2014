﻿define({
    titleBasemap: 'ก้_Base maps_ษฺ',
    titleLayers: 'ก้_Operational Layers_ษฺ',
    labelLayer: 'ก้_Layer Name_ษฺ',
    itemZoomTo: 'ก้_Zoom to_ษฺ',
    itemTransparency: 'ก้_Transparency_ษฺ',
    itemTransparent: 'ก้_Transparent_ษฺ',
    itemOpaque: 'ก้_Opaque_ษฺ',
    itemMoveUp: 'ก้_Move up_ษฺ',
    itemMoveDown: 'ก้_Move down_ษฺ',
    itemDesc: 'ก้_Description_ษฺ',
    itemDownload: 'ก้_Download_ษฺ',
    itemToAttributeTable: 'ก้_Open attribute table_ษฺ'
});

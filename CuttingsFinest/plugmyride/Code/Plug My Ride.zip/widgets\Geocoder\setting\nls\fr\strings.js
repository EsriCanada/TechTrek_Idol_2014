﻿define({

    placeholder: "æ_Placeholder Text_Â",
    url: "æ_Geocoder URL_Â",
    name: "æ_Geocoder Name_Â",
    singleLineFieldName: "æ_SingleLineFieldName_Â",
    portalConnectionError: 'æ_Can not get the configuratin of geocode from protal_Â',
    actions: "æ_Actions_Â",
    warning: "æ_Incorrect Service_Â",
    instruction: "æ_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_Â
    æ_"You can also reorder,configure,or delete your geocoders bleow._Â",
    add: "æ_Add Geocoder_Â",
    edit: "æ_Edit Geocoder_Â",
    ok: "æ_OK_Â",
    cancel: "æ_Cancel_Â",
    REPEATING_ERROR: "æ_The fllowing fields are repeated:_Â "
});
﻿define({
    titleBasemap: 'כן_Base maps_ש',
    titleLayers: 'כן_Operational Layers_ש',
    labelLayer: 'כן_Layer Name_ש',
    itemZoomTo: 'כן_Zoom to_ש',
    itemTransparency: 'כן_Transparency_ש',
    itemTransparent: 'כן_Transparent_ש',
    itemOpaque: 'כן_Opaque_ש',
    itemMoveUp: 'כן_Move up_ש',
    itemMoveDown: 'כן_Move down_ש',
    itemDesc: 'כן_Description_ש',
    itemDownload: 'כן_Download_ש',
    itemToAttributeTable: 'כן_Open attribute table_ש'
});

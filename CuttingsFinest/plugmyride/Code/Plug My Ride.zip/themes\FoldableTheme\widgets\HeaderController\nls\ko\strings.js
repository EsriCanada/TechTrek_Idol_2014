﻿define({
    signin: "한_Sign In_빠",
    signout: "한_Sign Out_빠",
    about: "한_About_빠",
    signInTo: "한_Sign in to_빠"
});

﻿define({
    label: "ł_Layer_ą",
    show: "ł_Show_ą",
    actions: "ł_Selection Symbol_ą",
    field: "ł_Field_ą",
    alias: "ł_Alias_ą",
    visible: "ł_Visible_ą",
    linkField: "ł_LinkField_ą",
    noLayers: "ł_No feature layers available_ą",
    back: "ł_Back_ą",
    exportCSV: "ł_Export to CSV_ą",
    restore: "ł_Restore to default value_ą",
    ok: "ł_OK_ą",
    result: "ł_Save successfully_ą",
    warning: "ł_Check to show this layer in table firstly._ą"
});
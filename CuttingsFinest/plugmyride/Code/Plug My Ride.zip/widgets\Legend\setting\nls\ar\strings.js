﻿define({
    arrangement: "بيت_Arrangement_لاحقة",
    autoUpdate: "بيت_Auto Update_لاحقة",
    respectCurrentMapScale: "بيت_Respect Current Map Scale_لاحقة"
});
﻿define({
    showLegend: "显示图例"
});
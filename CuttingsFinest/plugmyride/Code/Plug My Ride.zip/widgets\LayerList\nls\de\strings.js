﻿define({
    titleBasemap: 'ä_Base maps_Ü',
    titleLayers: 'ä_Operational Layers_Ü',
    labelLayer: 'ä_Layer Name_Ü',
    itemZoomTo: 'ä_Zoom to_Ü',
    itemTransparency: 'ä_Transparency_Ü',
    itemTransparent: 'ä_Transparent_Ü',
    itemOpaque: 'ä_Opaque_Ü',
    itemMoveUp: 'ä_Move up_Ü',
    itemMoveDown: 'ä_Move down_Ü',
    itemDesc: 'ä_Description_Ü',
    itemDownload: 'ä_Download_Ü',
    itemToAttributeTable: 'ä_Open attribute table_Ü'
});

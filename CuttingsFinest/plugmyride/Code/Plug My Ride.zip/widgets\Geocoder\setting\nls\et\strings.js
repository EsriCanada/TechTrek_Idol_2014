﻿define({

    placeholder: "Š_Placeholder Text_ä",
    url: "Š_Geocoder URL_ä",
    name: "Š_Geocoder Name_ä",
    singleLineFieldName: "Š_SingleLineFieldName_ä",
    portalConnectionError: 'Š_Can not get the configuratin of geocode from protal_ä',
    actions: "Š_Actions_ä",
    warning: "Š_Incorrect Service_ä",
    instruction: "Š_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ä
    Š_"You can also reorder,configure,or delete your geocoders bleow._ä",
    add: "Š_Add Geocoder_ä",
    edit: "Š_Edit Geocoder_ä",
    ok: "Š_OK_ä",
    cancel: "Š_Cancel_ä",
    REPEATING_ERROR: "Š_The fllowing fields are repeated:_ä "
});
﻿define({
    group: "ก้_Name_ษฺ",
    openAll: "ก้_Open All in Panel_ษฺ",
    dropDown: "ก้_Show in Drop-down Menu_ษฺ",
    noGroup: "ก้_There is no widget group set._ษฺ",
    groupSetLabel: "ก้_Set widget groups properties_ษฺ"
});
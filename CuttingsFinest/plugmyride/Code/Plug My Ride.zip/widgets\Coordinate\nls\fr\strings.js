﻿define({

    hintMessage: "æ_Click map to get coordinate_Â",
    defaultLabel: "æ_Default Settings_Â",
    realtimeLabel: "æ_Can Realtime Show_Â",
    computing: "æ_computing..._Â",
    latitudeLabel: "æ_Latitude_Â",
    longitudeLabel: "æ_Longitude_Â"
});
﻿define({
    showLegend: "Š_Show Legend_ä"
});
﻿define({
    group: "ø_Name_å",
    openAll: "ø_Open All in Panel_å",
    dropDown: "ø_Show in Drop-down Menu_å",
    noGroup: "ø_There is no widget group set._å",
    groupSetLabel: "ø_Set widget groups properties_å"
});
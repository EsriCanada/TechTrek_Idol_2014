﻿define({

    placeholder: "بيت_Placeholder Text_لاحقة",
    url: "بيت_Geocoder URL_لاحقة",
    name: "بيت_Geocoder Name_لاحقة",
    singleLineFieldName: "بيت_SingleLineFieldName_لاحقة",
    portalConnectionError: 'بيت_Can not get the configuratin of geocode from protal_لاحقة',
    actions: "بيت_Actions_لاحقة",
    warning: "بيت_Incorrect Service_لاحقة",
    instruction: "بيت_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_لاحقة
    بيت_"You can also reorder,configure,or delete your geocoders bleow._لاحقة",
    add: "بيت_Add Geocoder_لاحقة",
    edit: "بيت_Edit Geocoder_لاحقة",
    ok: "بيت_OK_لاحقة",
    cancel: "بيت_Cancel_لاحقة",
    REPEATING_ERROR: "بيت_The fllowing fields are repeated:_لاحقة "
});
﻿define({

    placeholder: "å_Placeholder Text_ø",
    url: "å_Geocoder URL_ø",
    name: "å_Geocoder Name_ø",
    singleLineFieldName: "å_SingleLineFieldName_ø",
    portalConnectionError: 'å_Can not get the configuratin of geocode from protal_ø',
    actions: "å_Actions_ø",
    warning: "å_Incorrect Service_ø",
    instruction: "å_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_ø
    å_"You can also reorder,configure,or delete your geocoders bleow._ø",
    add: "å_Add Geocoder_ø",
    edit: "å_Edit Geocoder_ø",
    ok: "å_OK_ø",
    cancel: "å_Cancel_ø",
    REPEATING_ERROR: "å_The fllowing fields are repeated:_ø "
});
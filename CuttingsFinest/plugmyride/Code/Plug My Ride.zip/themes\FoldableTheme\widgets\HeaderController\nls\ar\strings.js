﻿define({
    signin: "بيت_Sign In_لاحقة",
    signout: "بيت_Sign Out_لاحقة",
    about: "بيت_About_لاحقة",
    signInTo: "بيت_Sign in to_لاحقة"
});

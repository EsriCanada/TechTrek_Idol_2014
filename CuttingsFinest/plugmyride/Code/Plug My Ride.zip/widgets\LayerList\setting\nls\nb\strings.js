﻿define({
    showLegend: "å_Show Legend_ø"
});
﻿define({
    label: "ã_Layer_Ç",
    show: "ã_Show_Ç",
    actions: "ã_Selection Symbol_Ç",
    field: "ã_Field_Ç",
    alias: "ã_Alias_Ç",
    visible: "ã_Visible_Ç",
    linkField: "ã_LinkField_Ç",
    noLayers: "ã_No feature layers available_Ç",
    back: "ã_Back_Ç",
    exportCSV: "ã_Export to CSV_Ç",
    restore: "ã_Restore to default value_Ç",
    ok: "ã_OK_Ç",
    result: "ã_Save successfully_Ç",
    warning: "ã_Check to show this layer in table firstly._Ç"
});
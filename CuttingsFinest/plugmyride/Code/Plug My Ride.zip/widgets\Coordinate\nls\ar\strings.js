﻿define({

    hintMessage: "بيت_Click map to get coordinate_لاحقة",
    defaultLabel: "بيت_Default Settings_لاحقة",
    realtimeLabel: "بيت_Can Realtime Show_لاحقة",
    computing: "بيت_computing..._لاحقة",
    latitudeLabel: "بيت_Latitude_لاحقة",
    longitudeLabel: "بيت_Longitude_لاحقة"
});
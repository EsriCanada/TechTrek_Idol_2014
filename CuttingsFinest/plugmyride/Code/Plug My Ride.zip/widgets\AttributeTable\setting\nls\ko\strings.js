﻿define({
    label: "한_Layer_빠",
    show: "한_Show_빠",
    actions: "한_Selection Symbol_빠",
    field: "한_Field_빠",
    alias: "한_Alias_빠",
    visible: "한_Visible_빠",
    linkField: "한_LinkField_빠",
    noLayers: "한_No feature layers available_빠",
    back: "한_Back_빠",
    exportCSV: "한_Export to CSV_빠",
    restore: "한_Restore to default value_빠",
    ok: "한_OK_빠",
    result: "한_Save successfully_빠",
    warning: "한_Check to show this layer in table firstly._빠"
});
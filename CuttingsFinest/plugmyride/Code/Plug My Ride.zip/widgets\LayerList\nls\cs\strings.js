﻿define({
    titleBasemap: 'Ř_Base maps_ů',
    titleLayers: 'Ř_Operational Layers_ů',
    labelLayer: 'Ř_Layer Name_ů',
    itemZoomTo: 'Ř_Zoom to_ů',
    itemTransparency: 'Ř_Transparency_ů',
    itemTransparent: 'Ř_Transparent_ů',
    itemOpaque: 'Ř_Opaque_ů',
    itemMoveUp: 'Ř_Move up_ů',
    itemMoveDown: 'Ř_Move down_ů',
    itemDesc: 'Ř_Description_ů',
    itemDownload: 'Ř_Download_ů',
    itemToAttributeTable: 'Ř_Open attribute table_ů'
});

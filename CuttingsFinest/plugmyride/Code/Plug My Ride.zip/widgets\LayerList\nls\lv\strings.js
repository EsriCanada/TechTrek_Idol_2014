﻿define({
    titleBasemap: 'ķ_Base maps_ū',
    titleLayers: 'ķ_Operational Layers_ū',
    labelLayer: 'ķ_Layer Name_ū',
    itemZoomTo: 'ķ_Zoom to_ū',
    itemTransparency: 'ķ_Transparency_ū',
    itemTransparent: 'ķ_Transparent_ū',
    itemOpaque: 'ķ_Opaque_ū',
    itemMoveUp: 'ķ_Move up_ū',
    itemMoveDown: 'ķ_Move down_ū',
    itemDesc: 'ķ_Description_ū',
    itemDownload: 'ķ_Download_ū',
    itemToAttributeTable: 'ķ_Open attribute table_ū'
});

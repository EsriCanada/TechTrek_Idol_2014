﻿define({
    group: "ı_Name_İ",
    openAll: "ı_Open All in Panel_İ",
    dropDown: "ı_Show in Drop-down Menu_İ",
    noGroup: "ı_There is no widget group set._İ",
    groupSetLabel: "ı_Set widget groups properties_İ"
});
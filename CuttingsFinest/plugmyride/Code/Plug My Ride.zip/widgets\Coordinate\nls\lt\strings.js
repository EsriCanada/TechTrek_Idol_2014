﻿define({

    hintMessage: "Į_Click map to get coordinate_š",
    defaultLabel: "Į_Default Settings_š",
    realtimeLabel: "Į_Can Realtime Show_š",
    computing: "Į_computing..._š",
    latitudeLabel: "Į_Latitude_š",
    longitudeLabel: "Į_Longitude_š"
});
﻿define({
    titleBasemap: 'ø_Base maps_å',
    titleLayers: 'ø_Operational Layers_å',
    labelLayer: 'ø_Layer Name_å',
    itemZoomTo: 'ø_Zoom to_å',
    itemTransparency: 'ø_Transparency_å',
    itemTransparent: 'ø_Transparent_å',
    itemOpaque: 'ø_Opaque_å',
    itemMoveUp: 'ø_Move up_å',
    itemMoveDown: 'ø_Move down_å',
    itemDesc: 'ø_Description_å',
    itemDownload: 'ø_Download_å',
    itemToAttributeTable: 'ø_Open attribute table_å'
});

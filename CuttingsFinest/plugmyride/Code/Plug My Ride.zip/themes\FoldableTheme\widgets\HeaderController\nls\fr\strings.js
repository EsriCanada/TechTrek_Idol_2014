﻿define({
    signin: "æ_Sign In_Â",
    signout: "æ_Sign Out_Â",
    about: "æ_About_Â",
    signInTo: "æ_Sign in to_Â"
});

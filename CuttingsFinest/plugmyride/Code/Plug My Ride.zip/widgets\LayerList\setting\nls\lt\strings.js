﻿define({
    showLegend: "Į_Show Legend_š"
});
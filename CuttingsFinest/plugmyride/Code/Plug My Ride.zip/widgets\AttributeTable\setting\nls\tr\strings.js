﻿define({
    label: "ı_Layer_İ",
    show: "ı_Show_İ",
    actions: "ı_Selection Symbol_İ",
    field: "ı_Field_İ",
    alias: "ı_Alias_İ",
    visible: "ı_Visible_İ",
    linkField: "ı_LinkField_İ",
    noLayers: "ı_No feature layers available_İ",
    back: "ı_Back_İ",
    exportCSV: "ı_Export to CSV_İ",
    restore: "ı_Restore to default value_İ",
    ok: "ı_OK_İ",
    result: "ı_Save successfully_İ",
    warning: "ı_Check to show this layer in table firstly._İ"
});
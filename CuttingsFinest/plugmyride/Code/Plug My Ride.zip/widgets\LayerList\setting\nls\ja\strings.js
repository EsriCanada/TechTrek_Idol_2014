﻿define({
    showLegend: "須_Show Legend_鷗"
});
﻿define({
    showLegend: "ä_Show Legend_Ü"
});
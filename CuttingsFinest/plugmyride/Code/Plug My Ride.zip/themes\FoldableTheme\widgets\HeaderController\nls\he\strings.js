﻿define({
    signin: "כן_Sign In_ש",
    signout: "כן_Sign Out_ש",
    about: "כן_About_ש",
    signInTo: "כן_Sign in to_ש"
});

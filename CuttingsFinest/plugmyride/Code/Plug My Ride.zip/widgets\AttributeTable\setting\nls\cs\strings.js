﻿define({
    label: "Ř_Layer_ů",
    show: "Ř_Show_ů",
    actions: "Ř_Selection Symbol_ů",
    field: "Ř_Field_ů",
    alias: "Ř_Alias_ů",
    visible: "Ř_Visible_ů",
    linkField: "Ř_LinkField_ů",
    noLayers: "Ř_No feature layers available_ů",
    back: "Ř_Back_ů",
    exportCSV: "Ř_Export to CSV_ů",
    restore: "Ř_Restore to default value_ů",
    ok: "Ř_OK_ů",
    result: "Ř_Save successfully_ů",
    warning: "Ř_Check to show this layer in table firstly._ů"
});
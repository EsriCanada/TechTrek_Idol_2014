﻿define({
    label: "é_Layer_È",
    show: "é_Show_È",
    actions: "é_Selection Symbol_È",
    field: "é_Field_È",
    alias: "é_Alias_È",
    visible: "é_Visible_È",
    linkField: "é_LinkField_È",
    noLayers: "é_No feature layers available_È",
    back: "é_Back_È",
    exportCSV: "é_Export to CSV_È",
    restore: "é_Restore to default value_È",
    ok: "é_OK_È",
    result: "é_Save successfully_È",
    warning: "é_Check to show this layer in table firstly._È"
});
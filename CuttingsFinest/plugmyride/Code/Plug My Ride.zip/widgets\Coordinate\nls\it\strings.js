﻿define({

    hintMessage: "é_Click map to get coordinate_È",
    defaultLabel: "é_Default Settings_È",
    realtimeLabel: "é_Can Realtime Show_È",
    computing: "é_computing..._È",
    latitudeLabel: "é_Latitude_È",
    longitudeLabel: "é_Longitude_È"
});
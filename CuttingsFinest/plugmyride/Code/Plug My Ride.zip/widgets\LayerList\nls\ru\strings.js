﻿define({
    titleBasemap: 'Ж_Base maps_Я',
    titleLayers: 'Ж_Operational Layers_Я',
    labelLayer: 'Ж_Layer Name_Я',
    itemZoomTo: 'Ж_Zoom to_Я',
    itemTransparency: 'Ж_Transparency_Я',
    itemTransparent: 'Ж_Transparent_Я',
    itemOpaque: 'Ж_Opaque_Я',
    itemMoveUp: 'Ж_Move up_Я',
    itemMoveDown: 'Ж_Move down_Я',
    itemDesc: 'Ж_Description_Я',
    itemDownload: 'Ж_Download_Я',
    itemToAttributeTable: 'Ж_Open attribute table_Я'
});

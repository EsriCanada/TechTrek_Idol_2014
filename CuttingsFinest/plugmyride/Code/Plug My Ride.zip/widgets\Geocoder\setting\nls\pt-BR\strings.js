﻿define({

    placeholder: "ã_Placeholder Text_Ç",
    url: "ã_Geocoder URL_Ç",
    name: "ã_Geocoder Name_Ç",
    singleLineFieldName: "ã_SingleLineFieldName_Ç",
    portalConnectionError: 'ã_Can not get the configuratin of geocode from protal_Ç',
    actions: "ã_Actions_Ç",
    warning: "ã_Incorrect Service_Ç",
    instruction: "ã_Establish the geocoders that will be used in this widget. Click Add Geocoder to reference a URL, specify a user friendly name, and set other properties. " +_Ç
    ã_"You can also reorder,configure,or delete your geocoders bleow._Ç",
    add: "ã_Add Geocoder_Ç",
    edit: "ã_Edit Geocoder_Ç",
    ok: "ã_OK_Ç",
    cancel: "ã_Cancel_Ç",
    REPEATING_ERROR: "ã_The fllowing fields are repeated:_Ç "
});
﻿define({
    showLegend: "ø_Show Legend_å"
});
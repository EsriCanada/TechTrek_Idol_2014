﻿define({
    arrangement: "ä_Arrangement_Ü",
    autoUpdate: "ä_Auto Update_Ü",
    respectCurrentMapScale: "ä_Respect Current Map Scale_Ü"
});
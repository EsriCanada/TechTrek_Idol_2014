﻿define({
    arrangement: "ø_Arrangement_å",
    autoUpdate: "ø_Auto Update_å",
    respectCurrentMapScale: "ø_Respect Current Map Scale_å"
});
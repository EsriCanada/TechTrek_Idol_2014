﻿define({
    label: "Š_Layer_ä",
    show: "Š_Show_ä",
    actions: "Š_Selection Symbol_ä",
    field: "Š_Field_ä",
    alias: "Š_Alias_ä",
    visible: "Š_Visible_ä",
    linkField: "Š_LinkField_ä",
    noLayers: "Š_No feature layers available_ä",
    back: "Š_Back_ä",
    exportCSV: "Š_Export to CSV_ä",
    restore: "Š_Restore to default value_ä",
    ok: "Š_OK_ä",
    result: "Š_Save successfully_ä",
    warning: "Š_Check to show this layer in table firstly._ä"
});
﻿define({
    signin: "ä_Sign In_Ü",
    signout: "ä_Sign Out_Ü",
    about: "ä_About_Ü",
    signInTo: "ä_Sign in to_Ü"
});
